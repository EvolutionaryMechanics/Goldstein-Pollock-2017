package simulate;

import java.io.*;
import java.util.*;

/**
 *
 * @author Richard Goldstein
 */
public class Simulate {
    
    Protein protein;
    Structure nativeStructure;
    Vector<Structure> dummyStructureVector = new Vector<Structure>();
    Vector<Integer> fixedSiteVector = new Vector<Integer>();
    Hashtable<Integer, Character> fixedResidues = new Hashtable<Integer, Character>();
    String startingSequence = "";
    Params params = new Params();
    Sequences sequences = new Sequences();
    HashTables hashTables = new HashTables();
    public static Random random = new Random();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Simulate simulate = new Simulate(args);
        simulate.run();
    }

    Simulate(String[] arguments) {
        InteractionMatrix interactionMatrix = new InteractionMatrix();
        nativeStructure = new Structure(nativeProtein, interactionMatrix);
        for (int iDummy = 0; iDummy < dummyProteinList.length; iDummy++) {
            Structure dummyStructure = new Structure(dummyProteinList[iDummy], interactionMatrix);
            dummyStructureVector.add(dummyStructure);
        }
    }

    void run() {
        if (Params.CREATE_RANDOM_SEQUENCE) {
            protein = new Protein(nativeStructure, dummyStructureVector, fixedResidues);
        } else if (Params.CHOOSE_RANDOM_SEQUENCE) {
            if (Sequences.getSequenceListSize() == 0) {
                System.out.println("No available sequences: Does file Sequences exist?");
                System.exit(1);
            }
            int initialSequence = new Random().nextInt(Sequences.getSequenceListSize());
            protein = new Protein(nativeStructure, dummyStructureVector, initialSequence, fixedResidues);
        } else if (Params.INITIAL_SEQUENCE >= 0) {
            if (Sequences.getSequenceListSize() < Params.INITIAL_SEQUENCE+1) {
                System.out.println("Sequence not available: Does file Sequences exist?");
                System.exit(1);
            }
            protein = new Protein(nativeStructure, dummyStructureVector, Params.INITIAL_SEQUENCE, fixedResidues);
        } else if (Params.START_SEQUENCE.length() > 0) {
            protein = new Protein(nativeStructure, dummyStructureVector, Params.START_SEQUENCE, fixedResidues);
        }

        boolean finished = false;
        int iGen = 0;
        while (!finished) {
            protein.mutate(iGen);
            iGen++;
            if ((iGen > Params.N_GEN) || (protein.getTime() > Params.MAX_TIME)) {
                finished = true;
            }
        }
    }

    String[] nativeProtein = {"1qhw", "A"};
    String[][] dummyProteinList = {
        {"1mty", "B"},
        {"1n00", "A"},
        {"1gwu", "A"},
        {"1kwf", "A"},
        {"1iom", "A"},
        {"1jfb", "A"},
        {"1wer", " "},
        {"1hz4", "A"},
        {"1uby", " "},
        {"1t5j", "A"},
        {"1dmh", "A"},
        {"2bbv", "A"},
        {"1ojj", "A"},
        {"1nsz", "A"},
        {"1mkf", "A"},
        {"1jj2", "B"},
        {"1wkr", "A"},
        {"1gyh", "A"},
        {"3sil", " "},
        {"1pby", "B"},
        {"1o88", "A"},
        {"1odm", "A"},
        {"1jub", "A"},
        {"1ek6", "A"},
        {"1oc7", "A"},
        {"1jl5", "A"},
        {"1esd", " "},
        {"1jil", "A"},
        {"1t5o", "A"},
        {"1umd", "A"},
        {"1svm", "A"},
        {"1l5o", "A"},
        {"1ga6", "A"},
        {"1woh", "A"},
        {"1wch", "A"},
        {"1m4l", "A"},
        {"1nd6", "A"},
        {"1i4w", "A"},
        {"1o4s", "A"},
        {"1jkm", "A"},
        {"2mas", "A"},
        {"1rkd", " "},
        {"1e19", "A"},
        {"1cnz", "A"},
        {"1qop", "B"},
        {"1moq", " "},
        {"1v6s", "A"},
        {"1jix", "A"},
        {"1o7j", "A"},
        {"1pfk", "A"},
        {"1ir6", "A"},
        {"1to6", "A"},
        {"1qo0", "A"},
        {"1sbp", " "},
        {"1nbf", "A"}};

}
